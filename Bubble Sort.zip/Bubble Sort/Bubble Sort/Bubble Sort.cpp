#include <iostream>

class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        this->next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;

    LinkedList() {
        head = nullptr;
    }

    // Function to insert a node at the beginning of the list
    void insertAtBeginning(int data) {
        Node* newNode = new Node(data);
        newNode->next = head;
        head = newNode;
    }

    // Function to swap two nodes in the linked list
    void swapNodes(Node*& curr, Node* next) {
        // If nodes are non-consecutive (not adjacent)
        if (curr->next != next) {
            // Find the previous node of 'next'
            Node* prev = head;
            while (prev->next != next) {
                prev = prev->next;
            }

            // Change next's pointer to point to curr's next
            next->next = curr->next;

            // Change curr's next pointer to point to next's next
            curr->next = next->next;

            // Change prev's next pointer to point to curr
            prev->next = curr;
        }
        else {
            // Swap data if nodes are adjacent
            int temp = curr->data;
            curr->data = next->data;
            next->data = temp;
        }
    }

    // Function to sort the linked list using bubble sort
    void bubbleSort() {
        Node* curr;
        Node* next;

        // If head is null, list is empty
        if (head == nullptr) {
            return;
        }

        // Outer loop to make n-1 passes
        for (int i = 0; head != nullptr && head->next != nullptr; i++) {
            curr = head;
            next = curr->next;

            // Inner loop to compare adjacent nodes
            for (int j = 0; next; j++) {
                if (curr->data > next->data) {
                    swapNodes(curr, next);
                }
                curr = curr->next;
                next = (curr != nullptr) ? curr->next : nullptr;
            }
        }
    }

    // Function to print the linked list
    void printList() {
        Node* temp = head;
        while (temp) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }
};

int main() {
    LinkedList list;
    list.insertAtBeginning(90);
    list.insertAtBeginning(11);
    list.insertAtBeginning(22);
    list.insertAtBeginning(12);
    list.insertAtBeginning(25);
    list.insertAtBeginning(34);
    list.insertAtBeginning(64);

    std::cout << "Original list: ";
    list.printList();

    list.bubbleSort();

    std::cout << "Sorted list: ";
    list.printList();

    return 0;
}